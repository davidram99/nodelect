@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%%LOCALAPPDATA%%"=="" (
  >&2 echo nodelect: LOCALAPPDATA no definido
  exit /b 1
)

set "VERSION_PATH=%%LOCALAPPDATA%%\nodelect\nodejs\current"
if not exist "%%VERSION_PATH%%" (
  >&2 echo nodelect: sin version activa. Ejecuta 'nodelect use ^<version^>'
  exit /b 1
)

set /p "VERSION="<"%%VERSION_PATH%%"
if errorlevel 1 (
  >&2 echo nodelect: no se pudo leer el archivo de version
  exit /b 1
)
if "%%VERSION%%"=="" (
  >&2 echo nodelect: no hay version de node activa. Ejecuta 'nodelect use ^<version^>'
  exit /b 1
)

set "BINARY=%%~n0"
for %%%%L in (A=a B=b C=c D=d E=e F=f G=g H=h I=i J=j K=k L=l M=m N=n O=o P=p Q=q R=r S=s T=t U=u V=v W=w X=x Y=y Z=z) do (
  set "BINARY=!BINARY:%%%%L!"
)
if "!BINARY!"=="" (
  >&2 echo nodelect: no se pudo determinar el nombre del binario
  exit /b 1
)

set "TARGET_EXE=%%LOCALAPPDATA%%\nodelect\nodejs\versions\%%VERSION%%\!BINARY!.exe"
set "TARGET_CMD=%%LOCALAPPDATA%%\nodelect\nodejs\versions\%%VERSION%%\!BINARY!.cmd"

setlocal DisableDelayedExpansion
if exist "%%TARGET_EXE%%" goto :run_exe
if not exist "%%TARGET_CMD%%" (
  >&2 echo nodelect: no se encuentra '%%~n0' en version %%VERSION%%
  exit /b 1
)

cmd.exe /d /c ""%%TARGET_CMD%%" %%*"
set "EXIT_CODE=%%ERRORLEVEL%%"
exit /b %%EXIT_CODE%%

:run_exe
"%%TARGET_EXE%%" %%*
set "EXIT_CODE=%%ERRORLEVEL%%"
exit /b %%EXIT_CODE%%
